# InstaMubble
Async library for building Instagram bots using **SendPulse**


## Installing
`poetry add git+https://ghp_<TOKEN>@github.com/RAI-org/instamubble.git#main`


## Example
```python
from instamubble import InstaMubble, API, Message, MessageType

api = API("abc123", "cba321")
bot = InstaMubble(api)


@bot.message("start")  # Reacting on "start" message
async def start(message: Message):
    await message.answer("🥰 Hello! I'm InstaMubble library!\n\n🔫 Just try to type any message!")


@bot.message(MessageType.TEXT)  # Reacting on any message
async def any(message: Message):
    await message.answer(f"🔫 You typed: {message.text}, your ID: {message.contact_id}!")

bot.run_forever()

```