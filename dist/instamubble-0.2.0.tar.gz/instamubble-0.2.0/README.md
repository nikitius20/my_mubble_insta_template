# InstaMubble
Async library for building Instagram bots using **SendPulse**


## Installing
At first, you need to get your Github token: [From here](https://github.com/settings/tokens)

`poetry add git+https://ghp_<TOKEN>@github.com/RAI-org/instamubble.git#main`


## Example
```python
from instamubble import InstaMubble, API, Message, MessageType

api = API("ABC123", "abc123")
bot = InstaMubble(api)


@bot.message("start")
async def start(message: Message):
    await message.answer(
        "🥰 Hello! I'm InstaMubble library!\n\n🔫 Just try to type any message!"
    )


@bot.message(MessageType.IMAGE)
async def photo(message: Message):
    await message.answer("🔫 You sent a photo!")
    print(f"Image link: {message.data}")


@bot.message(MessageType.AUDIO)
async def audio(message: Message):
    await message.answer("🔫 You sent an audio!")
    print(f"Audio link: {message.data}")


@bot.message(MessageType.TEXT)
async def any(message: Message):
    await message.answer(f"🔫 You typed: {message.text}, your ID: {message.user_id}!")


bot.run_forever()
```