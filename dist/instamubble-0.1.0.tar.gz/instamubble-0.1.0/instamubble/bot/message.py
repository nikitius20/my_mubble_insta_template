import json
from aiohttp import ClientSession, ContentTypeError

from instamubble.api.api import API


class Message:
    URL = "https://api.sendpulse.com/instagram/contacts/send"

    def __init__(self, contact_id, text, api: API):
        self.contact_id = contact_id
        self.text = text
        self._api = api

    async def answer(self, text: str) -> dict:
        """
        Function that sends a message to the contact.
        """
        token = await self._api.get_access_token()
        headers = {
            "Authorization": f"Bearer {token}",
            "Content-Type": "application/json",
        }
        chunks = [text[i : i + 1000] for i in range(0, len(text), 1000)]
        for chunk in chunks:
            payload = {
                "contact_id": self.contact_id,
                "messages": [{"type": "text", "message": {"text": chunk}}],
            }
            response = await self._api.http.request_raw(
                self.URL, "POST", headers=headers, json=payload
            )
            if response.status != 200:
                response_text = await response.text()
                try:
                    response_data = await response.json(encoding="utf-8")
                    return {"error": response_data, "details": response_text}
                    break
                except ContentTypeError:
                    return {
                        "error": "Response is not JSON format",
                        "details": response_text,
                    }
        return {"status": "success", "details": "Message sent successfully"}
