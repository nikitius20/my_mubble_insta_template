from functools import wraps
import re
from ssl import SSLContext
from aiohttp import web
from instamubble.bot.message import Message
from instamubble.types.message import MessageType


class InstaMubble:
    def __init__(self, api):
        self.api = api

        self._message_handlers = []

    def __repr__(self) -> str:
        return (
            f"{self.__class__.__name__}: {self.api} {self.dispatch} {self.loop_wrapper}"
        )

    def message(self, text: str | None = None):
        def decorator(func):
            compiled_pattern = (
                text if isinstance(text, MessageType) else re.compile(text)
            )
            self._message_handlers.append((compiled_pattern, func))

            @wraps(func)
            def wrapper(*args, **kwargs):
                return func(*args, **kwargs)

            return wrapper

        return decorator

    async def handle_message(
        self, contact_id, message_type: MessageType, text: str | None = None
    ):
        message = Message(contact_id, text, self.api)
        for pattern, handler in self._message_handlers:
            if pattern == message_type or pattern.match(text):
                await handler(message)
                break

    async def webhook_handler(self, request):
        webhook_data = await request.json()
        try:
            contact_id = webhook_data[0]["contact"]["id"]
            message_text = webhook_data[0]["info"]["message"]["channel_data"][
                "message"
            ].get("text", "")
            message_type: MessageType.TEXT = MessageType.TEXT
        except KeyError:
            return web.Response(status=400, text="Invalid data")

        await self.handle_message(contact_id, message_type, message_text)

        return web.Response(status=200, text="Processed")

    def run_forever(self, host: str = "0.0.0.0", port: int = 4545):
        app = web.Application()
        app.add_routes([web.post("/webhook", self.webhook_handler)])
        web.run_app(app, host=host, port=port)